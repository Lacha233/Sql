The root of the REST API.

Make a GET request to this resource to obtain information about the available
API versions.
